# มีสุขส่งถึง v3 — Mobile App Style

รอบนี้แก้ใหม่โดยยึด mobile-first จริง ๆ

## UX หลัก
- มือถือเป็น 2 คอลัมน์สินค้าแบบ shopping app
- มี bottom navigation แบบแอป
- search + category sticky ตอนเลื่อน
- ปุ่มสินค้า 2 ปุ่มชัดเจน
  - เพิ่มลงตะกร้า
  - สั่งซื้อเลย
- ตะกร้าอยู่ bottom nav พร้อม badge
- checkout เป็น bottom sheet
- responsive:
  - desktop 4 columns
  - tablet 3 columns
  - mobile 2 columns
- soft pastel gradient + rounded cards
- ไม่มี emoji ใน UI

## LINE fix
แก้ deep link เป็น:
```js
const lineUrl = `https://line.me/R/oaMessage/@435ktnsf/?${encodeURIComponent(text)}`;
```

ไม่ใช้ `URLSearchParams`
ไม่ใส่ `text=`
ไม่ควรมี `+` แปลก ๆ ในข้อความแล้ว

## Order flow
สำคัญมาก:
1. ลูกค้ากดส่งออเดอร์
2. validate ชื่อ / ห้อง / โทร
3. save ลง Supabase ทันที
4. save order_items
5. รับ order_no
6. สร้างข้อความ
7. เปิด LINE

ดังนั้นแม้ LINE เปิดไม่สำเร็จ ออเดอร์ยังอยู่ใน database

## Supabase ต่อจาก README v2 ได้เลย
ตารางหลัก:
- products
- product_variants
- orders
- order_items

## รูปสินค้า
ตอนนี้ UI ใช้ placeholder panel เพื่อไม่สร้าง/บิดรูปสินค้า
Cody ให้ต่อ `image_url` จาก Supabase Storage แล้วใส่ `<img>` ของจริงใน `.thumb`
