const products = window.MEESOOK_PRODUCTS || [];
let selectedCat = "all";
let cart = {};

const $ = id => document.getElementById(id);
const currency = n => `฿${Number(n).toLocaleString("th-TH")}`;

const cartIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM6.2 5l.57 2H21l-1.8 7.15a2 2 0 0 1-1.94 1.52H9.1a2 2 0 0 1-1.95-1.56L4.11 2H1V0h4.63l.57 2.27L6.2 5Z"/></svg>`;

function labelFor(cat){
  return ({water:"WATER",rice:"RICE",noodle:"NOODLE",other:"STORE"})[cat] || "ITEM";
}
function getVariant(pid, vid){
  const p = products.find(x => x.id === pid);
  const v = p.variants.find(x => x.id === vid);
  return [p,v];
}
function filtered(){
  const q = $("search").value.trim().toLowerCase();
  return products.filter(p => (selectedCat==="all" || p.category===selectedCat) && (!q || `${p.name} ${p.subtitle||""}`.toLowerCase().includes(q)));
}
function card(p){
  const v = p.variants[0];
  return `<article class="product-card" data-id="${p.id}" data-variant="${v.id}">
    <div class="thumb">
      <span class="thumb-mark">${labelFor(p.category)}</span>
      <span class="stock-badge">คงเหลือ ${p.stock}</span>
    </div>
    <h4>${p.name}</h4>
    <div class="product-sub">${p.subtitle||""}</div>
    <div class="variant-wrap">${p.variants.map((x,i)=>`<button class="variant-btn ${i===0?"active":""}" data-p="${p.id}" data-v="${x.id}" type="button">${x.label} ${currency(x.price)}</button>`).join("")}</div>
    <div class="price-block"><strong>${currency(v.price)}</strong><span>/ ${v.label}</span></div>
    <div class="action-row">
      <button class="add-cart" data-add="${p.id}" type="button">${cartIcon}<span>เพิ่มลงตะกร้า</span></button>
      <button class="buy-now" data-buy="${p.id}" type="button">สั่งซื้อเลย</button>
    </div>
  </article>`;
}
function render(){
  const list = filtered();
  $("count").textContent = `${list.length} รายการ`;
  $("products").innerHTML = list.map(card).join("");
}
function lines(){return Object.values(cart)}
function qtyTotal(){return lines().reduce((s,x)=>s+x.qty,0)}
function priceTotal(){return lines().reduce((s,x)=>s+x.qty*x.price,0)}
function updateCart(){
  const qty = qtyTotal();
  $("sheetTotal").textContent = currency(priceTotal());
  $("navCartBadge").textContent = qty;
  $("navCartBadge").classList.toggle("hidden", qty===0);
  $("cartItems").innerHTML = qty ? lines().map(x=>`<div class="cart-item">
    <div><b>${x.name}</b><div class="item-meta">${x.variantLabel} · ${currency(x.price)} / ${x.variantLabel}</div></div>
    <div class="qty-box"><button data-minus="${x.key}" type="button">−</button><strong>${x.qty}</strong><button data-plus="${x.key}" type="button">+</button></div>
  </div>`).join("") : `<div class="item-meta" style="padding:10px 0">ยังไม่มีสินค้าในตะกร้า</div>`;
}
function add(pid, vid, replace=false){
  const [p,v]=getVariant(pid,vid), key=`${pid}__${vid}`;
  if(replace) cart={};
  if(!cart[key]) cart[key]={key,pid,vid,name:p.name,variantLabel:v.label,price:v.price,qty:0};
  cart[key].qty++;
  updateCart();
}
function openCart(){$("sheetWrap").classList.remove("hidden")}
function closeCart(){$("sheetWrap").classList.add("hidden")}

document.addEventListener("click",e=>{
  const cat=e.target.closest("[data-cat]");
  if(cat){selectedCat=cat.dataset.cat;document.querySelectorAll("[data-cat]").forEach(x=>x.classList.toggle("active",x===cat));render();return}

  const vb=e.target.closest("[data-p]");
  if(vb){
    const cardEl=vb.closest(".product-card");
    cardEl.dataset.variant=vb.dataset.v;
    cardEl.querySelectorAll(".variant-btn").forEach(x=>x.classList.toggle("active",x===vb));
    const [,v]=getVariant(vb.dataset.p,vb.dataset.v);
    cardEl.querySelector(".price-block").innerHTML=`<strong>${currency(v.price)}</strong><span>/ ${v.label}</span>`;
    return;
  }

  const a=e.target.closest("[data-add]");
  if(a){const cardEl=a.closest(".product-card");add(a.dataset.add,cardEl.dataset.variant);return}

  const b=e.target.closest("[data-buy]");
  if(b){const cardEl=b.closest(".product-card");add(b.dataset.buy,cardEl.dataset.variant,true);openCart();return}

  const plus=e.target.closest("[data-plus]");
  if(plus){cart[plus.dataset.plus].qty++;updateCart();return}
  const minus=e.target.closest("[data-minus]");
  if(minus){const k=minus.dataset.minus;cart[k].qty--;if(cart[k].qty<=0)delete cart[k];updateCart();return}

  if(e.target.closest("[data-open-cart]")){openCart();return}
  if(e.target.closest("[data-focus-search]")){$("search").focus();$("search").scrollIntoView({behavior:"smooth",block:"center"});return}
  if(e.target.closest("[data-scroll-home]")){window.scrollTo({top:0,behavior:"smooth"});return}
});

$("search").addEventListener("input",render);
$("closeSheet").addEventListener("click",closeCart);
$("sheetWrap").addEventListener("click",e=>{if(e.target===$("sheetWrap"))closeCart()});

function buildOrderText(orderNo){
  const itemLines = lines().map(x=>`• ${x.name} (${x.variantLabel}) x${x.qty} = ${x.price*x.qty} บาท`);
  const note=$("note").value.trim()||"-";
  const pickup=$("pickupTime").value.trim()||"-";
  return [
    `คำสั่งซื้อจาก มีสุขส่งถึง`,
    orderNo ? `เลขออเดอร์: ${orderNo}` : null,
    ``,
    `รายการสินค้า`,
    ...itemLines,
    ``,
    `ยอดรวม`,
    `${priceTotal()} บาท`,
    ``,
    `ข้อมูลผู้สั่ง`,
    `ชื่อ: ${$("name").value.trim()}`,
    `ห้อง: ${$("room").value.trim()}`,
    `โทร: ${$("phone").value.trim()}`,
    `เวลารับของ: ${pickup}`,
    `หมายเหตุ: ${note}`,
    ``,
    `จัดส่ง`,
    `ส่งฟรีที่ล็อบบี้ IDEO MOBI EASTGATE`,
    `พื้นที่ใกล้เคียงสามารถสอบถามเพิ่มเติมได้`
  ].filter(x=>x!==null).join("\n");
}

$("orderLine").addEventListener("click", async()=>{
  if(!lines().length){alert("กรุณาเลือกสินค้าอย่างน้อย 1 รายการ");return}
  if(!$("name").value.trim()||!$("room").value.trim()||!$("phone").value.trim()){
    alert("กรอกชื่อ เลขห้อง และเบอร์โทรก่อนนะคะ");return
  }

  // TODO Cody: save order + order_items into Supabase FIRST
  // const savedOrder = await createOrder(...)
  // const orderNo = savedOrder.order_no
  const orderNo = "";

  const text = buildOrderText(orderNo);
  const lineUrl = `https://line.me/R/oaMessage/@435ktnsf/?${encodeURIComponent(text)}`;
  window.location.href = lineUrl;
});

render();updateCart();